        <link rel="stylesheet" href="../css/styles.css" type="text/css">  <!--link the external css file-->

        <!--global navigation file for all pages-->
        <nav>
            <ul>  <!--unordered list-->

                <li><a href="../index.php">HOME</a></li>   <!--for index.php file-->
                <li><a href="../about_us.php">ABOUT</a></li>  <!--for about_us file-->
                <li><a href="../products.php">PRODUCTS</a></li>  <!--for products file-->
                <li><a href="../reviews.php">REVIEWS</a></li>  <!--for reviews file-->
                <li><a href="../support.php">SUPPORT</a></li>   <!--for support file-->
                <li><a href="../corporate-info.php">CORPORATE INFORMATION</a>  <!--for corporate information file-->


            </ul>  <!--end of unordered list-->
        </nav>  <!--end of nav tag-->